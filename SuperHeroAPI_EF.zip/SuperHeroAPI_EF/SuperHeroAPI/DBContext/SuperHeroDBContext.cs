﻿using Microsoft.EntityFrameworkCore;
using SuperHeroAPI.Entity;
using System.Collections.Generic;
using System.Xml;

namespace SuperHeroAPI.DBContext
{
    public class SuperHeroDBContext : DbContext
    {

        public DbSet<SuperHero> SuperHeros { get; set; }

        public SuperHeroDBContext(DbContextOptions<SuperHeroDBContext> options) : base(options)
        {
        } 

    }
}
