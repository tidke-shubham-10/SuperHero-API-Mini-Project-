﻿using SuperHeroAPI.Entity;

namespace SuperHeroAPI.Interfaces
{
    public interface ISuperHeroServices
    {
        List<SuperHero> GetAllHeroes();
        SuperHero GetHeroByUId(string uId);
        SuperHero AddHero(SuperHero newHero);
        SuperHero UpdateHero(SuperHero newHero);
        SuperHero DeleteHero(string uId);
    }
}
