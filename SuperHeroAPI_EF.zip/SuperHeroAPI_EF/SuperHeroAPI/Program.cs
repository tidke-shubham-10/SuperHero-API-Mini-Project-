using SuperHeroAPI.Interfaces;
using SuperHeroAPI.Services;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using SuperHeroAPI.DBContext;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<SuperHeroDBContext>(options => options.UseMySQL("Server=localhost; User ID=root; Password=root; Database=SuperHeroDB"), ServiceLifetime.Singleton);

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers(Options => Options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true);
builder.Services.AddSingleton<ISuperHeroServices, SuperHeroServices>();
// builder.Services.AddSingleton<ICosmosDBServices, CosmosDBServices>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
