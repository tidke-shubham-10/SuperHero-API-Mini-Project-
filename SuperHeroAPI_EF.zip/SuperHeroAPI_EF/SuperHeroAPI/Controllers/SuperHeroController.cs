﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using SuperHeroAPI.Entity;
using SuperHeroAPI.Interfaces;

namespace SuperHeroAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SuperHeroController : ControllerBase
    {
        private readonly ISuperHeroServices _superHeroServices;

        public SuperHeroController(ISuperHeroServices superHeroServices)
        {
            _superHeroServices = superHeroServices;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllHeroes()
        {
            return Ok(_superHeroServices.GetAllHeroes());
        }
        [HttpGet]
        public async Task<IActionResult> GetSingleHero(string uId)
        {
            var result = _superHeroServices.GetHeroByUId(uId);
            if (result == null) return NotFound("Sorry, record not found");
            return Ok(result);
        }
        [HttpPost]
        public async Task<IActionResult> AddHero(SuperHero hero)
        {
            return Ok(_superHeroServices.AddHero(hero));
        }
        [HttpPost]
        public async Task<IActionResult> UpdateHero(SuperHero superHero)
        {
            return Ok(_superHeroServices.UpdateHero(superHero));
        }
        [HttpPost]
        public async Task<IActionResult> DeleteHero(string uId)
        {
            return Ok(_superHeroServices.DeleteHero(uId));
        }
    }
}
