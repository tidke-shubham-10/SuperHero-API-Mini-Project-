﻿using SuperHeroAPI.Entity;
using SuperHeroAPI.Interfaces;
using Microsoft.Azure.Cosmos;
using Container = Microsoft.Azure.Cosmos.Container;
using SuperHeroAPI.DBContext;

namespace SuperHeroAPI.Services
{
    public class SuperHeroServices : ISuperHeroServices
    {

        private readonly SuperHeroDBContext _context;

        public SuperHeroServices(SuperHeroDBContext context)
        {
            _context = context;
        }
                
        public SuperHero AddHero(SuperHero newHero)
        {
            // Container cn = _cosmosDBServices.CreateDBConnection();
            newHero.UId = Guid.NewGuid().ToString();
            newHero.Id = newHero.UId;
            newHero.Active = true;
            newHero.Archived = false;
            newHero.Version = 1;
            newHero.CreatedOn = DateTime.UtcNow;
            newHero.UpdatedOn = DateTime.UtcNow;
            newHero.dType = "Hero";

            //cn.CreateItemAsync(newHero).Wait();
            _context.SuperHeros.AddAsync(newHero);
            _context.SaveChangesAsync();
            return newHero;
        }

        public List<SuperHero> GetAllHeroes()
        {
            // List<SuperHero> superHeroes = new List<SuperHero>();
            var listOfSuperHeroes = _context.SuperHeros.Where(superHero => superHero.Archived == false).ToList();
            return listOfSuperHeroes;
            
        }

        public SuperHero GetHeroByUId(string uId)
        {
            var linq = _context.SuperHeros.Where(superHero => (superHero.UId.Equals(uId) && superHero.Archived == false)).FirstOrDefault<SuperHero>();

            return linq;
        }
        public SuperHero UpdateHero(SuperHero newHero)
        {
            //get & do changes
            SuperHero existingHero = this.GetHeroByUId(newHero.UId);
            existingHero.Archived = true;
            _context.SaveChanges();

            //add new entry
            newHero.Id = Guid.NewGuid().ToString();
            newHero.UId = existingHero.UId;
            newHero.dType = "Hero";
            newHero.Active = true;
            newHero.Archived = false;
            newHero.Version = existingHero.Version+1;
            newHero.CreatedOn = existingHero.CreatedOn;
            newHero.UpdatedOn = DateTime.UtcNow;

            _context.SuperHeros.AddAsync(newHero);
            _context.SaveChanges();
            return newHero;
        }
        public SuperHero DeleteHero(string uId)
        {
            SuperHero existingHero = this.GetHeroByUId(uId);
            existingHero.Archived = true;
            // existingHero.Active = false;
            _context.SaveChangesAsync();
            return existingHero;
        }
    }
}
