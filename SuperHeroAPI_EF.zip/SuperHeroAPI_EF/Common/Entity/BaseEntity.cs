﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace Common.Entity
{
    public class BaseEntity
    {
        [JsonProperty(PropertyName="id")]
        public string Id { get; set; }
        [JsonProperty(PropertyName="uId")]
        public string UId { get; set; }
        [JsonProperty(PropertyName = "createdOn")]
        public DateTime CreatedOn { get; set; }
        [JsonProperty(PropertyName = "updatedOn")]
        public DateTime UpdatedOn { get; set; }
        [JsonProperty(PropertyName = "archived")]
        public bool Archived { get; set; }
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }
        [JsonProperty(PropertyName = "version")]
        public int Version { get; set; }
        public string dType { get; set; }
    }
}